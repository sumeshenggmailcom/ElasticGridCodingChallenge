﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class UnitTestEGrid
    {
        [TestMethod]
        public void PossitiveSchenarioForChecking_IsNullOrEmpty()
        {
            bool expectedResult = true;
            string stringToCheck = null;
            bool actualResult = ElasticGrid.Extensions.IsNullOrEmpty(stringToCheck);
            Assert.AreEqual(expectedResult,actualResult);           
        }
        [TestMethod]
        public void NegativeSchenarioForChecking_IsNullOrEmpty()
        {
            bool expectedResult = false;
            string stringToCheck = "a";
            bool actualResult = ElasticGrid.Extensions.IsNullOrEmpty(stringToCheck);
            Assert.AreEqual(expectedResult, actualResult);
        }
        [TestMethod]
        public void PossitiveSchenarioForChecking_Factors_60()
        {
            int[] expectedResult= {1,2,3,4,5,6,10,12,15,20,30,60};
            int numberGetFactors = 60;
            int[] actualResultArray = ElasticGrid.Program.Factors(numberGetFactors);
            Assert.AreEqual(expectedResult.Length, actualResultArray.Length);

            for (int i = 0; i < actualResultArray.Length;i++ )
            {
                Assert.AreEqual(expectedResult[i], actualResultArray[i]);
            }
                       
        }
        [TestMethod]
        public void PossitiveSchenarioForChecking_Factors_42()
        {
            int[] expectedResult = {1,2,3,6,7,14,21,42};
            int numberGetFactors = 42;
            int[] actualResultArray = ElasticGrid.Program.Factors(numberGetFactors);
            Assert.AreEqual(expectedResult.Length, actualResultArray.Length);

            for (int i = 0; i < actualResultArray.Length; i++)
            {
                Assert.AreEqual(expectedResult[i], actualResultArray[i]);
            }
        }
        [TestMethod]
        public void PossitiveSchenarioForChecking_AreaOfTrangle()
        {
            double expectedResult = 6;
            int sideA=3,sideB=4,sideC=5;
            double actualResultArray = ElasticGrid.Program.AreaOfTrangle(sideA,sideB,sideC);
            Assert.AreEqual<double>(expectedResult, actualResultArray);
        }
        [TestMethod]
        public void NegativeSchenarioForChecking_AreaOfTrangle()
        {
            int sideA = 3, sideB = -4, sideC = 5;
            // act
            try
            {
                double actualResultArray = ElasticGrid.Program.AreaOfTrangle(sideA, sideB, sideC);
            }
            catch (ArgumentException e)
            {
                // assert
                StringAssert.Contains(e.Message,"Invalild Trangle Exception");
                return;
            }
            Assert.Fail("No exception was thrown.");           
            
        }
        [TestMethod]
        public void PossitiveSchenarioForChecking_MostPopular()
        {
            int[] expectedResult = {5,4};
            int[] arrayToCheck = { 5, 4, 3, 2, 4, 5, 1, 6, 1, 2, 5, 4 };
            int[] actualResultArray = ElasticGrid.Program.MostPopular(arrayToCheck);
            Assert.AreEqual(expectedResult.Length, actualResultArray.Length);

            for (int i = 0; i < actualResultArray.Length; i++)
            {
                Assert.AreEqual(expectedResult[i], actualResultArray[i]);
            }

        }
    }
}
