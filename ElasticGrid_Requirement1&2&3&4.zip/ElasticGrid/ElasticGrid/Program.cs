﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElasticGrid
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            try
            {
                //Requirement1 function calling in main program
                string newString = "";
                if (newString.IsNullOrEmpty())
                {
                    // Do Something
                }

                //Requirement2 function calling in main program
                foreach (int i in Factors(42))
                {
                    Console.WriteLine(i);
                }

                //Requirement3 function calling in main program
                double area = AreaOfTrangle(3, 4, 5);

                //Requirement4 function calling in main program
                int[] array = { 1, 2, 3, 4, 5, 6, 7 };
                array = MostPopular(array).ToArray();
            }
            catch (Exception ex)
            { ExceptionUtility.LogException(ex); }
        }

        //Requirement2 function body       
        public static int[] Factors(this int i)
        {
            if (i > 0)
            {
                var factors = from positiveDiv in Enumerable.Range(1, i)
                              where positiveDiv.Divisor(i)
                              select positiveDiv;
                return factors.ToArray();
            }
            else { throw new System.ArgumentException("Invalild number!"); }
        }
        public static bool Divisor(this int positiveDiv, int i)
        {
            return i % positiveDiv == 0;
        }

        //Requirement3 function body  
        public static double AreaOfTrangle(Int32 A, Int32 B, Int32 C)
            {
                if((A <= 0 || B <= 0 || C <= 0)||(A+B<C)||(A+C<B)||(B+C<A))
                {
                    throw new System.ArgumentException("Invalild Trangle Exception");
                }else{
                double i = (A + B + C) / 2d; 
                return Math.Round(Math.Sqrt(i * (i - A) * (i - B) * (i - C)), 1);
                }
            }

        //Requirement4 function body  
        public static int[] MostPopular(int[] array)
        {           
            var rankings = array.GroupBy(x=>x)
                                .SelectMany((g, i) =>
                                   g.Select(e => new { Text = g.Key, Count = g.Count() }))
                               .ToList();
            int max = rankings.Max(i => i.Count);
            var item = rankings.Where((x) => x.Count == max).Distinct().Select(x=>x.Text).ToArray();
            return item;
        }       
    }

    //Requirement1 Extensions class  
    public static class Extensions
    {
        //Requirement1 Extensions method 
        public static bool IsNullOrEmpty(this string s)
        {
            return (s == null || s.Length == 0);
        }
       
    }
}
